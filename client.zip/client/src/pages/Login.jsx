import { Login as LoginComponents } from "../components/index";

function Login() {
  return (
    <div className="py-7">
      <LoginComponents />
    </div>
  );
}

export default Login;
