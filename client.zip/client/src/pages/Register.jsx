import { Register as RegisterComponent } from "../components/index";

function Register() {
  return (
    <div className="py-7">
      <RegisterComponent />
    </div>
  );
}

export default Register;
