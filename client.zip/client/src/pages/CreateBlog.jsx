import { BlogForm } from "../components/index";

function CreateBlog() {
  return (
    <div>
      <BlogForm />
    </div>
  );
}

export default CreateBlog;
