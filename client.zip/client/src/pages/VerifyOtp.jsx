import React from 'react';
import OtpVerification from '../components/OtpVerification';

const VerifyOtp = () => {
  return <OtpVerification />;
};

export default VerifyOtp;
